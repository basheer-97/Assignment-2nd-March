#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np


# In[2]:


df=pd.read_csv('terror_gtd.csv', encoding = 'latin1')


# In[3]:


df


# In[4]:


df.country_txt.value_counts()


# In[5]:


new_df=df[df['success']==1]


# In[6]:


new_df['country_txt'].value_counts(ascending=False).head(1)


# In[7]:


#1
df[df['success']==1]['country_txt'].value_counts(ascending=False).head(1)


# In[14]:


df.head(1)


# In[9]:


new_df=df['country_txt'].value_counts()


# In[10]:


new_df['Iraq']


# In[11]:


new_df['India']


# In[20]:


#2
new_df1=df[df['nkill']>0]


# In[22]:


new_df1[(df['country_txt']=='India')& (df['nkill']<=7)].shape[0]


# In[26]:


#3
new_df2=df[['country_txt','nkill','city']].head(4)


# In[27]:


new_df2.describe()


# In[46]:


d1=df[df['country_txt']=='India'].sort_values("nkill",ascending=False)


# In[47]:


d1[['city','nkill']].head(3)


# In[63]:


#5
d2=df.query('country_txt=="India"').groupby('city').agg({'nkill':np.max,'nwound':np.max})
d2.sort_values(["nkill",'nwound'],ascending=[False,False]).head(5)


# In[81]:


#6
def func(x):
    if x['nkill']>10:
        return 'severe'
df['label']=df.apply(func,axis=1)


# In[71]:


df.head()


# In[ ]:





# In[ ]:





# In[77]:


#7
df[(df['success']==1)& (df['suicide']==1)].shape[0]


# In[78]:


df[(df['success']==0)& (df['suicide']==1)].shape[0]


# In[82]:


#8
def func(x):
    if x['success']==1 &x['suicide']==1:
        return 'success'
    else:
        'Fail'
    
df['successful suicide attack']=df.apply(func,axis=1)


# In[86]:


df[df['successful suicide attack']=='success']


# In[12]:





# In[4]:


#9
def func1(x):
    if (x['country_txt']=='India')|(x['country_txt']=='Afghanistan')|(x['country_txt']=='Paksistan'):
        return 'Afg-Pak-Ind'
    else:
        return'ROW'
df['Local']=df.apply(func1,axis=1)


# In[5]:


#10
df['Local'].value_counts()





# In[6]:


#11
df_local=df[df['Local']=='Afg-Pak-Ind']
df_row= df[df['Local']=='ROW']
output_dict={'Average_kills':[np.mean(df_row['nkill']),np.mean(df_local['nkill'])],'Number_Incidents':[df_row[df['suicide']==1].shape[0],df_local[df['suicide']==1].shape[0]]}
pd.DataFrame(output_dict, index=['ROW','Afg-Pak-India'])


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




