#!/usr/bin/env python
# coding: utf-8

# In[1]:


Last_Name=['Potter','Riddle','Dumbledore']
First_Name=['Harry','Tom','Albus']
Age=[18,15,120]
Profession=['Student','Magician','Headmaster']


# In[2]:


Age[2]


# In[5]:


First_Name[0:2]


# In[6]:


Profession[0::2]


# In[7]:


import sys


# In[8]:


print(sys.version)


# In[9]:


print(abs.__doc__)


# In[12]:


start_exam_date=(26,6,2018)
day,mon,year=start_exam_date
print('The examination will start from {}/{}/{}'.format(day,mon,year))


# In[15]:


d1={0:10,1:20}
d1


# In[16]:


d1.update({2:30})
d1


# In[20]:


import os


# In[ ]:





# In[22]:


os.getcwd()


# In[24]:


path ='C:\\Users\\shrupatnaik\\unext assignment'


# In[25]:


with open('Campaign_File.txt', 'w') as f:
    f.write('Create a new text file!')


# In[28]:


f1 = open("Campaign_File.txt", "r")

f2 = open("sample file 2.txt", "w")


for line in f1:

     f2.write(line.upper())


# In[32]:


with open('sample file 2.txt') as f:
    lines = f.readlines()
    print(lines)


# In[ ]:




