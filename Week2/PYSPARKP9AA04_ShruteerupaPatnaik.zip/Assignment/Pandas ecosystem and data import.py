#!/usr/bin/env python
# coding: utf-8

# In[17]:


import pandas as pd
import numpy as np


# In[18]:


data={'name':['Anastasia','Dima','Katherine','James','Emily','Michael','Mathew','Laura','Kevin','Jonas'],
     'score':[12,2,9,16.5,np.nan,9,20,14.5,8,19],'attempts':[1,3,2,3,2,3,1,1,2,1],
     'qualify':['yes','no','yes','no','no','yes','yes','no','no','yes'],
     'labels':['a','b','c','d','e','f','g','h','i','j']}


# In[19]:


df=pd.DataFrame(data)


# In[20]:


df


# In[21]:


df.to_csv('file1.csv')


# In[22]:


scores=pd.read_csv('file1.csv')


# In[23]:


scores.set_index('labels',inplace=True)


# In[24]:


column=scores.shape[0]
column


# In[25]:


rows=scores.shape[1]
rows


# In[26]:


scores.info()


# In[27]:


scores.describe()


# In[28]:


scores.head(3)


# In[30]:


scores[['name','score']]


# In[ ]:





# In[15]:


scores.at['d','score']=11.5


# In[16]:


scores


# In[ ]:




