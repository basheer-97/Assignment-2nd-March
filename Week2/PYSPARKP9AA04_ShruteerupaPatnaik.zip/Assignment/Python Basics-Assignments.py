#!/usr/bin/env python
# coding: utf-8

# In[4]:


def grade(phy,chem,maths):
    avg=(phy+chem+maths)/3
    if avg>=70 :
        print('DISTINCTION')
    if avg>=60 and avg<70:
        print('FIRST DIVISION')
    if avg>=50 and avg<60:
        print('SECOND DIVISION')
    if avg>=40 and avg<70:
        print('THIRD DIVISION')
    if avg<40:
        print('FAIL')
    


# In[5]:


grade(100,100,100)


# In[11]:


def sum_digit(n):
    sum1=0
    while(n>0):
            sum1=sum1+n%10
            n=n//10
    return sum1


# In[15]:


i=int(input())
sum_digit(i)


# In[24]:


def sumprimes(ls):
    sum2=0
    for n in ls:
        if n>1:
            for i in range(2,n):
                if n%i==0:
                    break
            else:
                sum2=sum2+n
    return sum2


# In[26]:


ls=[3,3,1,13]
sumprimes(ls)


# In[28]:


d={2:3, 1:89, 4:5, 3:0}
dict(sorted(d.items()))
{1: 89, 2: 3, 3: 0, 4: 5}


# In[31]:


l=[1,2,3,4,5]
for i in l[::-1]:
    print(i,end=' ')


# In[14]:


def merge(l1,l2):
    l1.extend(l2)
    l1.sort()
    
    return l1


# In[15]:


l1=[1,5,2,6]
l1.sort()
l2=[3,7,5,6]
l2.sort()
merge(l1,l2)


# In[3]:


def Remove(l):
    l1 = []
    for num in l:
        if num not in l1:
            l1.append(num)
    return l1


# In[4]:


l=[2,2,3,4,6,6,7,2]
Remove(l)


# In[9]:


def isAscending(list):
    prev = list[0]
    for n in list:
        if n < prev:
            return False
        prev = n
    return True


# In[11]:


isAscending([6,2,4])


# In[ ]:




